<?php $__env->startSection('title'); ?>
<?php echo e($single_product->title); ?> | Lara E-commerce
          

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>



	<div class="single-image">
		<img class="img" src="<?php echo e(asset('storage')); ?>/<?php echo e($product_image->image); ?>" alt="<?php echo e($single_product->title); ?>">
		<h5 class="text-center"> <?php echo e($single_product->title); ?></h5>
		<p> <?php if($single_product->quantity > 0): ?>
		
			<?php else: ?> Product:
			<span class="badge badge-warning ">
			Not available

		</span>

			<?php endif; ?></p>

		
			<p>

				<?php if($single_product->category->id == NULL ): ?>
				

				<?php else: ?>
				Category:
				<span class="badge badge-info ">
			

				<?php echo e($single_product->category->name); ?>

		</span>

					
				<?php endif; ?>

				


			</p>

			<p>

				<?php if($single_product->brand->id == NULL ): ?>
				

				<?php else: ?>
				Brand:
				<span class="badge badge-info ">
			

				<?php echo e($single_product->brand->name); ?>

		</span>

					
				<?php endif; ?>

				


			</p>
			
			
		<a href="#" class="btn btn-block btn-sm btn-primary  ">Add to card</a>
			

	</div>

   
	


<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="widget">








				<table class="table table-bordered">
	<h5 class="text-center">
		Product - <?php echo e($single_product->title); ?>

	
	</h5>

    <thead>
      <tr>
        <td>Name</td>
        <td><?php echo e($single_product->title); ?> </td>
       
       
      </tr>
      <tr>
        <td>Description</td>
        <td><?php echo e($single_product->description); ?> </td>
       
       
      </tr><tr>
        <td>Price</td>
        <td><?php echo e($single_product->price); ?> </td>
       
       
      </tr><tr>
        <td>Offer Price</td>
        
        <td><?php echo e($single_product->offer_price); ?></td>
       
       
      </tr>

    </thead>
   
      
      
   
  </table>
	
			</div>
		</div>
	</div>
</div>

	




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>