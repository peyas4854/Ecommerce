<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
        <div class="col-md-8 offset-2">
          <?php if(session('status')): ?>
      <div class="alert alert-success">
    <?php echo e(session('status')); ?>


</div>

      <?php endif; ?>
      <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card">
            


          

                        <div class="card-body">
                            <form action="<?php echo e(url('/product_store')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <h3 class="text-center">Add product </h3>

                        <div class="form-group">
                         <label for="usr">Product  title </label>

                         <input type="text" class="form-control" placeholder="Enter about title" name="title">
                        </div>

                        <div class="form-group">
                         <label for="usr">Description </label>
                          <textarea class="form-control" rows="5" placeholder="Enter about description" name="description"></textarea>
                        </div>
             

                        
                        <div class="form-group">
                         <label for="usr">Price </label>

                         <input type="number" class="form-control" id="usr" placeholder="Enter about quantity" name="price">

                        </div>
                        <div class="form-group">
                         <label for="usr">Category </label>

                         <select name="category_id"class="form-control" >
                           
                           <option value="" >select one</option>
                           <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             
                           <option value="<?php echo e($info->id); ?>" ><?php echo e($info->name); ?> </option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                         </select>

                        </div>
                        
                        
                        <div class="form-group">

                         <label for="usr"> image </label>

                         <input type="file" class="form-control" id="usr" placeholder="Enter about point" name="image">
                        </div>

                         <button type="submit" class="btn btn-success">Submit</button>
           </form>
                </div>
          
          
        </div>
      </div>
       
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>