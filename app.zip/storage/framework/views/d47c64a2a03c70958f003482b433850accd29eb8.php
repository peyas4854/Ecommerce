<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
        <div class="col-md-8 offset-2">
          <?php if(session('status')): ?>
      <div class="alert alert-success">
    <?php echo e(session('status')); ?>


</div>

      <?php endif; ?>
          <div class="card">
            


          

                        <div class="card-body">
                            <form action="<?php echo e(url('/store_category')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <h3 class="text-center">Add Category </h3>

                        <div class="form-group">
                         <label for="usr">Name </label>

                         <input type="text" class="form-control" placeholder="Enter about title" name="name">
                        </div>

                        <div class="form-group">
                         <label for="usr">Description </label>
                          <textarea class="form-control" rows="5" placeholder="Enter about description" name="description"></textarea>
                        </div>
             

                        
                        <div class="form-group">
                         <label for="usr">Parent Category </label>

                         <select name="parent_id" id="" class="form-control">
                          <?php $__currentLoopData = $category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                           <option value="<?php echo e($info->parent_id); ?>"><?php echo e($info->name); ?></option>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                         </select>

                        </div>
                        
                        
                        <div class="form-group">

                         <label for="usr"> image </label>

                         <input type="file" class="form-control" id="usr" placeholder="" name="image">
                        </div>

                         <button type="submit" class="btn btn-success">Submit</button>
           </form>
                </div>
          
          
        </div>
      </div>
       
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>