<?php $__env->startSection('content'); ?>
<div class="container">
  <div class="row">
        <div class="col-md-8 offset-2">
            <?php if(session('status')): ?>
      <div class="alert alert-success">
    <?php echo e(session('status')); ?>


</div>

      <?php endif; ?>
          <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
          <div class="card">
            


          

                        <div class="card-body">
                            <form action="<?php echo e(url('/product_update')); ?>" method="post" enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>

                                <h3 class="text-center">Edit product </h3>

                        <div class="form-group">
                         <label for="usr">Product  title </label>
                          <input type="hidden"  class="form-control"  name="id" value="<?php echo e($old_product->id); ?>">

                         <input type="text" class="form-control" placeholder="Enter about title" name="title" value="<?php echo e($old_product->title); ?>">
                        </div>
<div class="form-group">
                         <label for="usr">Description </label>

                         <input type="text" class="form-control" placeholder="Enter about title" name="description" value="<?php echo e($old_product->description); ?>">
                        </div>

                        
             

                        
                        <div class="form-group">
                         <label for="usr">Price </label>

                         <input type="number" class="form-control" id="usr" placeholder="Enter about quantity" name="price" value="<?php echo e($old_product->price); ?>">

                        </div>
                        
                        
                        <!-- <div class="form-group">
                        
                         <label for="usr"> image </label>
                        
                         <input type="file" class="form-control" id="usr" placeholder="Enter about point" name="image">
                        </div> -->

                         <button type="submit" class="btn btn-success">Update</button>
           </form>
                </div>
          
          
        </div>
      </div>
       
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>