<?php $__env->startSection('content'); ?>

<div class="widget margin-top">
                <div class="row">
                    <div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div><div class="col-md-3">
                        <div class="card single-item" >
  <img class="card-img-top" src="<?php echo e(asset('images/nokia 1.jpg')); ?>" alt="Card image">
  <div class="card-body">
    <h4 class="card-title">John Doe</h4>
    <p class="card-text">Some example text.</p>
    <a href="#" class="btn btn-primary">See Profile</a>
  </div>
</div>
          

                   
            </div>

            
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>