<?php $__env->startSection('content'); ?>

<div class="widget margin-top">
                <div class="row">

                 <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                    <div class="col-md-3">
                        <div class="card single-item" >

  
    
  <!-- <img class="card-img-top" src="<?php echo e(asset('images/1.jpg')); ?>" alt="Card image"> -->
  <?php
    $i=1;
  ?>
  <?php $__currentLoopData = $product->images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
  <?php if($i>0): ?>
    
    <img class="card-img-top" src="<?php echo e(asset('storage')); ?>/<?php echo e($image->image); ?>" alt="Card image">
  <?php endif; ?>
  <?php
    $i--;
  ?>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 

  <div class="card-body">
    <h4 class="card-title">
      <?php echo e($product->title); ?>

    </h4>
    <p class="card-text">
      <?php echo e($product->description); ?>

    </p>
    <p class="card-text">
      <label>Tk.</label><?php echo e($product->price); ?>

    </p>
    <a href="#" class="btn btn-primary">See more </a>
  </div>
</div>
          
                   
            </div>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
            
        </div>
        

    </div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>