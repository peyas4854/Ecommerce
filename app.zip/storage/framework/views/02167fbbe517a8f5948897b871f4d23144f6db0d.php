<div class="list-group margin-top">
	
<?php $__currentLoopData = App\category::orderBy('name','asc')->where('parent_id',NULL)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $parent_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
	
  <a  data-toggle="collapse" class="list-group-item list-group-item-action" href="#main-<?php echo e($parent_category->id); ?>" role="button" >
  	<img src="<?php echo e(asset('/storage')); ?>/<?php echo e($parent_category->image); ?>" alt="<?php echo e($parent_category->name); ?>" width="40"> <?php echo e($parent_category->name); ?>

    
  </a>


  
<div class="collapse sub" id="main-<?php echo e($parent_category->id); ?>">

	<div class="child-rows">
		<?php $__currentLoopData = App\category::orderBy('name','asc')->where('parent_id',$parent_category->id)->get(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sub_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

		

	<a href="<?php echo e(url('/category' )); ?>/<?php echo e($sub_category->id); ?>"   class="list-group-item list-group-item-action"  >
	
	  	<?php echo e($sub_category->name); ?>

	  	<?php echo e($sub_category->id); ?>

	    
	  </a>
	
	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		

	</div>
	
  
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- <div class="container">
  
  <ul class="nav flex-column">
    <li class="nav-item">
      <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" href="#">Link</a>
    </li>
    <li class="nav-item">
      <a class="nav-link disabled" href="#">Disabled</a>
    </li>
  </ul>
</div> -->
  



</div>