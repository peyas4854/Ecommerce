<?php $__env->startSection('sidebar'); ?>
<h2>sidebar</h2>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p class="text-center">

<h4> All produtcs in Category  : <span class="badge badge-info"><?php echo e($category->name); ?> </span></h4>
</p>

<?php
	$products=$category->products()->paginate(9);
?>

<?php if($products->count()>0): ?>
 <?php echo $__env->make('front-end.product.partials.product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	
	<?php else: ?>
	<div class="alert alert-warning">
		<p>no product found</p>
	</div>			
	
<?php endif; ?>





<?php $__env->stopSection(); ?>




<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>