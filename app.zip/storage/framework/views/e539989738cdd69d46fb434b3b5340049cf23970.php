<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
    <div class="col-md-12">
      
    
       
         <div class="card" >
  <div class="card-body">
    <h5 class="card-title">brand List</h5>
    <?php if(session('status')): ?>
      <div class="alert alert-danger">
    <?php echo e(session('status')); ?>


</div>

      <?php endif; ?>
      <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Id</th>
     
      <th scope="col">Name</th>
      <th scope="col">Description</th>
     
      <th scope="col">Image</th>
      <th scope="col">Action</th>

     

    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $brand; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
    <tr>
      <th scope="row"><?php echo e($info->id); ?></th>
      <td><?php echo e($info->name); ?> </td>
      <td><?php echo e($info->description); ?> </td>
     
      

      <td> <img src="<?php echo e(asset('storage')); ?>/<?php echo e($info->image); ?>" <?php echo e($info->name); ?>></td>
      
    
     
     
      
      <td>
        
        
  <a href="<?php echo e(url('/brand/delete')); ?>/<?php echo e($info->id); ?>" ><i class="fa fa-trash-alt"></i></a> | |
  <a href="<?php echo e(route('brand.edit',$info->id)); ?>"><i class="fa fa-user-edit"></i></a>| |
  <a href="#"><i class=" fas fa-info-circle"></i></a>

      </td>
     
      
    </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
  </div>

      </div>
    </div>
       
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>