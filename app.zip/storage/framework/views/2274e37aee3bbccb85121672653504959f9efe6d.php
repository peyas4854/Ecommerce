<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <div class="row">
        <div class="col-md-12">
         <div class="card" >
  <div class="card-body">
    <h5 class="card-title">Product List</h5>
    <?php if(session('status')): ?>
      <div class="alert alert-danger">
    <?php echo e(session('status')); ?>


</div>

      <?php endif; ?>
      <?php if($errors->any()): ?>
    <div class="alert alert-danger">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>
    
    <table class="table table-striped">
  <thead>
    <tr>
      <th scope="col">Id</th>
     
      <th scope="col">Brand</th>
     
      <th scope="col">Title</th>
     
     
      <th scope="col">Price</th>
      <th scope="col">Status</th>
      <th scope="col">Action</th>

     

    </tr>
  </thead>
  <tbody>
    <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      
    <tr>
      <th scope="row"><?php echo e($product->id); ?></th>
     
      <td><?php echo e($product->brand_id); ?></td>
      
      <td><?php echo e($product->title); ?></td>
     
     
      <td><?php echo e($product->price); ?></td>
      <td>
        <?php if($product->status == 1): ?>
          <i class="fas fa-check-square fa-2x" ></i>
        
        <?php else: ?>
        <span class="btn btn-warning">deactive</span>
      
        <?php endif; ?>
        
      </td>
      <td>
        
        
  <a href="<?php echo e(url('/product_delete')); ?>/<?php echo e($product->id); ?>" ><i class="fa fa-trash-alt"></i></a> | |
  <a href="<?php echo e(url('/product_edit')); ?>/<?php echo e($product->id); ?>"><i class="fa fa-user-edit"></i></a>| |
  <a href="#"><i class=" fas fa-info-circle"></i></a>

      </td>
     
      
    </tr>
    
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    
  </tbody>
</table>
  </div>
</div>
      </div>
       
      </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>