<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>E-commerce</title>
     <?php echo $__env->make('partials.style', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    
</head>
<body>

    <div class="wrapper">
       <!--  start navbar -->
        <nav>
          <?php echo $__env->make('partials.nav', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </nav>
<!-- end navbar -->

<!--  start side bar + content  -->
<div class="container">
    <div class="row">
       <!--  side  -->
        <div class="col-md-3">
          <div class="sidebar">
            <?php echo $__env->make('partials.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            
          </div>
            


            
        </div>
        <!-- content -->

        <div class="col-md-9">
          <?php echo $__env->yieldContent('content'); ?>
            
</div>
<!--  end  side bar + content  -->



    </div>
  </div>
  <footer>
    <?php echo $__env->make('partials.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</footer>
    
   


 <?php echo $__env->make('partials.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    
</body>
</html>