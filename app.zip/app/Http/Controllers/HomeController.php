<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\brand;
use App\product;
use App\product_image;
use App\category;


use Carbon\carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       // $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('/dashboard/index');
    }
    public function all_product()
    {
        $products = product::orderBy('id','desc')->paginate(15);
        $product_image= product_image::all();
        //echo $product_image;
        

        
        
       
        return view('/front-end/product/all_product',compact('products','product_image'));
    }
    public function product()
    {
         $category = category::where('parent_id',NULL)->get();

        return view('dashboard/pages/product',compact('category'));
    }
    public function brand()
    {
        return view('backend/brand');
    }
    public function category()
    {
        return view('backend/category');
    }
    
public function product_store(Request $request)
    {
        $request->validate([
            'title'=>'required',
            'price'=>'required',
            'image'=>'required',
        ]);


        $info=product::insertGetId([
            "brand_id"=>1,
            "admin_id"=>1,
            "title"=>$request->title,
            "category_id"=>$request->category_id,
            "description"=>$request->description,
            "slug"=>str_slug($request->title),
           
            "price"=>$request->price,
            "status"=>1,
            "created_at"=>Carbon::now()

        ]);
       
       if ($request->hasFile('image')) {
         $path = $request->file('image')->store('product_image');

        product_image::insert([
            "product_id"=>$info,
            "image"=>$path
        ]);
       

    }
       return back()->with('status','Product added successfully!');
}

public function category_product($id){
   $category= Category::find($id);
   if (!is_null($category)){
    return view('/front-end.category.category_product',compact('category'));

   }
  else{
    echo "no ";
  }
}
}
