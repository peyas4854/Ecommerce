<?php

/*auth*/
Auth::routes();
/*page controller*/


/*

-----front-end-------
*/
Route::get('/','ProductController@index');
Route::get('/all_product','HomeController@all_product');
Route::get('/category/{id}','HomeController@category_product');



/*back-end*/

Route::get('/home', 'HomeController@index');
/*
============ admin-product =======
 */
Route::get('/product', 'HomeController@product');
Route::get('/show_product','ProductController@show_product');
Route::get('/product_edit/{id}','ProductController@product_edit');
Route::get('/product_delete/{id}','ProductController@product_delete');
Route::post('/product_store', 'HomeController@product_store');
Route::post('/product_update', 'ProductController@product_update');
Route::get('/single_product/{slug}','ProductController@single_product');
Route::post('/search_product', 'ProductController@search_product');





/*
=======
 admin-brand -----------
=======
 */
Route::get('/brand', 'HomeController@brand');
Route::post('/brand_store', 'HomeController@brand_store');

Route::resource('/brand', 'BrandController');
Route::get('/brand/delete/{id}', 'BrandController@delete');







/*----admin-category ----*/
Route::get('/show_category', 'CategoryController@index');
Route::get('/add_category', 'CategoryController@add');
Route::post('/store_category', 'CategoryController@store');
Route::get('/delete_category/{id}', 'CategoryController@delete_category');


