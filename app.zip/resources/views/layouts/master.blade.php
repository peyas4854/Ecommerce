<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>

      @yield('title','Lara E-commerce')
   

  </title>
     @include('partials.style')

    
</head>
<body>

    <div class="wrapper">
       <!--  start navbar -->
        <nav>
          @include('partials.nav')
        </nav>
<!-- end navbar -->

<!--  start side bar + content  -->
<div class="container">
    <div class="row">
       <!--  side  -->
        <div class="col-md-3">
          <div class="sidebar">

           @yield('sidebar')
            
          </div>
         
            


            
        </div>
        <!-- content -->

        <div class="col-md-9">
          @yield('content')
            
</div>
<!--  end  side bar + content  -->



    </div>
  </div>
  <footer>
    @include('partials.footer')
</footer>
    
   


 @include('partials.scripts')
    
</body>
</html>