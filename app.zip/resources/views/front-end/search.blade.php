@extends('layouts.master')


@section('sidebar')

            @include('partials.sidebar')

@endsection

@section('content')
<p class="text-center">
	
	


<h4>Search by : <span class="badge badge-info"> {{$search}}</span></h4>

</p>

 @include('front-end.product.partials.product')


@endsection



