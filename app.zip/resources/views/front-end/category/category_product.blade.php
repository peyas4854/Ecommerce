@extends('layouts.master')

@section('sidebar')
<h2>sidebar</h2>
@endsection

@section('content')
<p class="text-center">

<h4> All produtcs in Category  : <span class="badge badge-info">{{$category->name}} </span></h4>
</p>

@php
	$products=$category->products()->paginate(9);
@endphp

@if ($products->count()>0)
 @include('front-end.product.partials.product')
	{{-- expr --}}
	@else
	<div class="alert alert-warning">
		<p>no product found</p>
	</div>			
	
@endif





@endsection



