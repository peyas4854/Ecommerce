@extends('layouts.master')

@section('sidebar')
<h2>sidebar</h2>
@endsection

@section('content')


@include('front-end.product.partials.product')



@endsection



