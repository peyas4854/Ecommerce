@extends('layouts.master')
@section('title')
{{ $single_product->title}} | Lara E-commerce
          

@endsection


@section('sidebar')



	<div class="single-image">
		<img class="img" src="{{asset('storage')}}/{{$product_image->image}}" alt="{{ $single_product->title}}">
		<h5 class="text-center"> {{ $single_product->title}}</h5>
		<p> @if($single_product->quantity > 0)
		
			@else Product:
			<span class="badge badge-warning ">
			Not available

		</span>

			@endif</p>

		
			<p>

				@if ($single_product->category->id == NULL )
				

				@else
				Category:
				<span class="badge badge-info ">
			

				{{$single_product->category->name }}
		</span>

					
				@endif

				


			</p>

			<p>

				@if ($single_product->brand->id == NULL )
				

				@else
				Brand:
				<span class="badge badge-info ">
			

				{{$single_product->brand->name }}
		</span>

					
				@endif

				


			</p>
			
			
		<a href="#" class="btn btn-block btn-sm btn-primary  ">Add to card</a>
			

	</div>

   
	


@endsection

@section('content')
<div class="container">
	<div class="row">
		<div class="col-md-8">
			<div class="widget">








				<table class="table table-bordered">
	<h5 class="text-center">
		Product - {{ $single_product->title}}
	
	</h5>

    <thead>
      <tr>
        <td>Name</td>
        <td>{{ $single_product->title}} </td>
       
       
      </tr>
      <tr>
        <td>Description</td>
        <td>{{ $single_product->description}} </td>
       
       
      </tr><tr>
        <td>Price</td>
        <td>{{ $single_product->price}} </td>
       
       
      </tr><tr>
        <td>Offer Price</td>
        
        <td>{{$single_product->offer_price}}</td>
       
       
      </tr>

    </thead>
   
      
      
   
  </table>
	
			</div>
		</div>
	</div>
</div>

	




@endsection
