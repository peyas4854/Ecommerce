@extends('layouts.master')





@section('sidebar')

            @include('partials.sidebar')

@endsection

@section('content')

 @include('front-end.product.partials.product')


@endsection



