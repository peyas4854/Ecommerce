<div class="list-group">
  <a href="{{ url('/product') }}" class="list-group-item list-group-item-action">Product</a>
  <a href="{{ url('/brand') }}" class="list-group-item list-group-item-action">brand</a>
  <a href="{{ url('/category') }}" class="list-group-item list-group-item-action">Category</a>
</div>