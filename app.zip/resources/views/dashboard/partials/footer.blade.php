
          <footer>
          	  <p class="text-center">&copy; 2019 All right received || E-commerce</p>
          </footer>

        